# CS 499 MilestoneFour Artifact Package (Option A: Original + Enhanced)

This ZIP includes **both** the unmodified original artifact and the enhanced version submitted for this milestone.

## Folder Structure
- `original/` — Original MovieGeek source files (baseline before CS 499 enhancements)
  - `moviegeek-master/` (complete project)
- `enhanced/` — Enhanced artifact files used for this milestone (exact contents from the milestone submission)

## Notes
- The original folder is included to satisfy the requirement to submit **all technical files (original and enhanced code)** in one archive.
- The enhanced folder contents match the milestone version (software / algorithms / databases enhancements depending on milestone).

Jordan Swe
