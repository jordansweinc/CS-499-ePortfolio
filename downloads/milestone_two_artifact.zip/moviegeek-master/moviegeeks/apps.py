from django.apps import AppConfig


class MoviegeeksConfig(AppConfig):
    name = 'moviegeeks'
