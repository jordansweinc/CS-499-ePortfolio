"""
Business logic for retrieving movie data.

This module defines high level functions used by the views layer to
retrieve movies, genres and other related objects.  By centralising
data access here, the views remain thin and easier to test, while the
query logic is kept in one place.  Functions in this module may raise
exceptions if invalid arguments are supplied or if queries fail.
"""

from typing import Iterable, Optional
import logging
from django.db.models import QuerySet
from django.core.cache import cache

from moviegeeks.models import Movie, Genre

logger = logging.getLogger(__name__)

def list_genres() -> Iterable[str]:
    """Return a list of distinct genre names."""
    key = "genres_all"
    genres = cache.get(key)
    if genres is None:
        logger.debug("Cache miss for genres, querying database.")
        genres = list(Genre.objects.values_list("name", flat=True).distinct())
        cache.set(key, genres, 60 * 60)  # cache for one hour
    return genres


def list_movies(genre_name: Optional[str] = None) -> QuerySet:
    """
    Return a queryset of movies optionally filtered by genre name.

    Movies are ordered by year descending then by movie_id ascending.
    A cache is used for top-level queries without genre filtering.
    """
    if genre_name:
        try:
            selected_genre = Genre.objects.get(name=genre_name)
        except Genre.DoesNotExist:
            logger.warning("Requested genre %s does not exist.", genre_name)
            return Movie.objects.none()
        qs = selected_genre.movies.order_by("-year", "movie_id")
    else:
        # Cache the list of all movies to avoid repeated database hits
        key = "movies_all"
        qs = cache.get(key)
        if qs is None:
            logger.debug("Cache miss for movies, querying database.")
            qs = Movie.objects.order_by("-year", "movie_id")
            cache.set(key, qs, 10 * 60)  # cache for 10 minutes
    return qs


def get_movie(movie_id: str) -> Optional[Movie]:
    """
    Return a single movie by its ID or None if not found.

    This function uses a short-lived cache since movie details rarely change.
    """
    key = f"movie_{movie_id}"
    movie = cache.get(key)
    if movie is None:
        logger.debug("Cache miss for movie %s, querying database.", movie_id)
        movie = Movie.objects.filter(movie_id=movie_id).first()
        cache.set(key, movie, 10 * 60)  # cache for 10 minutes
    return movie