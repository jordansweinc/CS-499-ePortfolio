from recs.base_recommender import base_recommender
from analytics.models import Rating
from recommender.models import Similarity
from django.db.models import Q
import time

from decimal import Decimal


class NeighborhoodBasedRecs(base_recommender):

    """
    Item-based nearest neighbour recommender.

    This recommender uses the precomputed Similarity table to generate item recommendations
    for a given user.  It caches computed prediction values to avoid redundant work when
    evaluating many items for the same set of ratings.  If a user has no rating history
    (a so-called cold start), the recommender falls back to a popularity-based
    recommendation strategy provided by ``PopularityBasedRecs``.

    :param neighborhood_size: number of similar items to consider when computing a prediction
    :param min_sim: minimum similarity threshold for candidate items
    :param max_candidates: maximum number of candidate items to inspect per user
    """
    def __init__(self, neighborhood_size=15, min_sim=0.0):
        self.neighborhood_size = neighborhood_size
        self.min_sim = min_sim
        self.max_candidates = 100
        # an in-memory cache for prediction scores.  Keys are tuples of
        # (target_item_id, frozenset of user rating pairs) and values are Decimal scores.
        # This avoids recomputing the same prediction multiple times, which is common
        # during evaluation.
        self._score_cache = {}

    def recommend_items(self, user_id, num=6):

        active_user_items = Rating.objects.filter(user_id=user_id).order_by('-rating')[:100]

        return self.recommend_items_by_ratings(user_id, active_user_items.values())

    def recommend_items_by_ratings(self, user_id, active_user_items, num=6):
        """
        Recommend items for a user based on the items they have already rated.

        If the user has no ratings (``active_user_items`` is empty), this method
        delegates to ``PopularityBasedRecs`` to provide a sensible fallback.

        :param user_id: The id of the user to generate recommendations for
        :param active_user_items: An iterable of dicts with ``movie_id`` and ``rating`` keys
        :param num: The number of recommendations to return
        :return: A list of (item_id, details) tuples sorted by predicted rating
        """

        # Cold start: no ratings, use popularity-based recommendations
        if len(active_user_items) == 0:
            # fall back to popularity-based recommender if the user has no ratings
            from .popularity_recommender import PopularityBasedRecs
            return PopularityBasedRecs().recommend_items(user_id, num=num)

        # build a dictionary of rated items and compute the mean user rating
        movie_ids = {movie['movie_id']: movie['rating'] for movie in active_user_items}
        user_mean = sum(movie_ids.values()) / len(movie_ids)

        # find candidate similar items above our similarity threshold that the user
        # hasn't rated yet
        candidate_items = Similarity.objects.filter(Q(source__in=movie_ids.keys())
                                                    & ~Q(target__in=movie_ids.keys())
                                                    & Q(similarity__gt=self.min_sim))
        candidate_items = candidate_items.order_by('-similarity')[:self.max_candidates]

        recs = dict()
        # group candidate items by their target to evaluate neighborhood similarity
        for candidate in candidate_items:
            target = candidate.target
            # collect up to ``neighborhood_size`` items that are similar to this target
            rated_items = [i for i in candidate_items if i.target == target][:self.neighborhood_size]
            if len(rated_items) > 1:
                pre = Decimal(0)
                sim_sum = Decimal(0)
                # accumulate the weighted deviations from the user mean
                for sim_item in rated_items:
                    r = Decimal(movie_ids[sim_item.source] - user_mean)
                    pre += sim_item.similarity * r
                    sim_sum += sim_item.similarity
                if sim_sum > 0:
                    recs[target] = {
                        'prediction': Decimal(user_mean) + pre / sim_sum,
                        'sim_items': [r.source for r in rated_items]
                    }

        # sort by predicted score descending and return top ``num``
        sorted_items = sorted(recs.items(), key=lambda item: -float(item[1]['prediction']))[:num]
        return sorted_items

    def predict_score(self, user_id, item_id):

        user_items = Rating.objects.filter(user_id=user_id)
        user_items = user_items.exclude(movie_id=item_id).order_by('-rating')[:100]
        movie_ids = {movie.movie_id: movie.rating for movie in user_items}

        return self.predict_score_by_ratings(item_id, movie_ids)

    def predict_score_by_ratings(self, item_id, movie_ids):
        """
        Predict the score for a target item based on the user's provided ratings.

        To avoid redundant computations, this method caches predictions keyed on
        the target ``item_id`` and the set of rated items.  This significantly
        speeds up evaluation when the same rating set is used for multiple
        predictions.

        :param item_id: the id of the item whose rating we want to predict
        :param movie_ids: a dictionary of {movie_id: rating}
        :return: Decimal predicted rating or 0 if no similar items found
        """
        # create a hashable cache key from the item_id and the rated movies
        # movie_ids is a dict -> convert to sorted tuple of items
        key = (item_id, tuple(sorted(movie_ids.items())))
        if key in self._score_cache:
            return self._score_cache[key]

        top = Decimal(0.0)
        bottom = Decimal(0.0)
        ids = movie_ids.keys()
        mc = self.max_candidates
        candidate_items = (Similarity.objects.filter(source__in=ids)
                                             .exclude(source=item_id)
                                             .filter(target=item_id))
        candidate_items = candidate_items.distinct().order_by('-similarity')[:mc]
        if len(candidate_items) == 0:
            return Decimal(0)

        for sim_item in candidate_items:
            r = movie_ids[sim_item.source]
            top += sim_item.similarity * r
            bottom += sim_item.similarity

        # avoid division by zero
        if bottom == 0:
            return Decimal(0)

        result = Decimal(top / bottom)
        # store in cache
        self._score_cache[key] = result
        return result
