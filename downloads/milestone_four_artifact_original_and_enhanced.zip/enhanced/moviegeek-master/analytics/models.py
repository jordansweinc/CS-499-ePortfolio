from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator


class Rating(models.Model):
    """
    Stores an explicit rating for a user and a movie.

    This model has been enhanced for Milestone Four to include
    a composite index on ``user_id`` and ``movie_id`` to speed up
    recommendation queries.  In addition, the ``rating`` field now
    includes validators to enforce a sensible range of values (0.0–5.0).
    """
    user_id = models.CharField(max_length=16)
    movie_id = models.CharField(max_length=16)
    rating = models.DecimalField(
        decimal_places=2,
        max_digits=4,
        validators=[
            MinValueValidator(0.0),
            MaxValueValidator(5.0),
        ],
        help_text="Rating value between 0.0 and 5.0",
    )
    rating_timestamp = models.DateTimeField()
    type = models.CharField(max_length=8, default='explicit')

    class Meta:
        indexes = [
            models.Index(fields=['user_id', 'movie_id'], name='idx_user_movie'),
        ]

    def __str__(self):
        return "user_id: {}, movie_id: {}, rating: {}, type: {}"\
            .format(self.user_id, self.movie_id, self.rating, self.type)


class Cluster(models.Model):
    cluster_id = models.IntegerField()
    user_id = models.IntegerField()

    def __str__(self):
        return "{} in {}".format(self.user_id, self.cluster_id)
