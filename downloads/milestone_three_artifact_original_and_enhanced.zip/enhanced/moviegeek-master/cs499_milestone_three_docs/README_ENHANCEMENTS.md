# Milestone Three Enhancements – Algorithms and Data Structures

This file summarizes the improvements made to the MovieGeek recommender system as part of **Milestone Three**.  The goal of these enhancements was to optimize the item‑based neighbourhood recommender and to demonstrate proficiency in algorithms and data structures.

## Overview

In the original MovieGeek implementation, the neighbourhood‑based recommender computed prediction scores by repeatedly traversing lists of similarity records and user ratings.  There was no caching of computed values and no fallback strategy when a user had no ratings (a cold‑start scenario).  These limitations led to unnecessary repeated calculations and poor recommendations for new users.

## Key Enhancements

- **Caching prediction results:** We added an in‑memory cache to `recs/neighborhood_based_recommender.py`.  The cache key combines the target item ID with a sorted tuple of `(movie_id, rating)` pairs from the user’s rating set.  When the same combination is encountered again, the cached score is returned instead of recomputing it, reducing redundant work.
- **Cold‑start fallback:** In `recommend_items_by_ratings`, when the user has no rated items, the recommender now delegates to the popularity‑based recommender (`recs/popularity_recommender.PopularityBasedRecs`) to produce recommendations.  This prevents empty results and improves usability for new users.
- **Defensive coding:** The prediction routine now checks for an empty similarity list and for zero similarity sums to avoid division‑by‑zero errors, returning a prediction of zero in those cases.  These checks make the algorithm more robust.
- **Documentation and comments:** We added docstrings and inline comments to clarify the behaviour of key functions (`recommend_items_by_ratings` and `predict_score_by_ratings`) and to explain the caching strategy and fallback logic.  This improves code readability and maintainability.

## Files Modified

- **`recs/neighborhood_based_recommender.py`** – added caching dictionary, cold‑start fallback logic, docstrings, input checks, and explanatory comments.
- No other algorithm files required changes; the remaining recommenders (`bpr_recommender`, `funksvd_recommender`, etc.) remain as originally supplied by the open‑source project.

## Impact

These enhancements decrease the time complexity of repeated evaluation runs, provide sensible recommendations for users with no ratings, and demonstrate the use of appropriate data structures (a dictionary for caching and a sorted tuple for immutable cache keys).  They also illustrate the integration of multiple recommender strategies within a cohesive design.

## Related Documentation

The accompanying narrative document (`Milestone_Three_Enhanced_Narrative_with_Diagrams.docx`) offers a detailed explanation of the rationale behind these changes and how they align with CS‑499 outcomes.  The algorithm pipeline diagram embedded in that document visualizes the recommendation flow with the new caching layer.