## Milestone Four: Database Enhancement Narrative

### Brief description of the artifact

For my database enhancement I selected the **MovieGeek** recommendation engine’s
data layer.  This application stores user ratings, movie metadata, similarity
metrics and precomputed recommendations in a relational database via Django’s
Object–Relational Mapper.  The core models were written several semesters ago as
part of a recommender systems course and were carried forward into the CS 499
capstone.  While functional, the original schema lacked indexing for
performance, offered no mechanism for caching recommendation results, and
hard‑coded its database settings.

### Justification for inclusion

I chose this artifact for the databases category of my ePortfolio because it
demonstrates my ability to design, extend and optimize data models.  The
enhancements implemented for Milestone Four showcase several database skills:

* **Performance tuning** – Adding a composite index on the `Rating` model’s
  `user_id` and `movie_id` fields speeds up queries used by the recommendation
  engine.  Without an index, retrieving ratings for a particular user and
  movie required a full table scan, which becomes untenable as the dataset
  grows.  The new index allows the database to perform a key‑based lookup.

* **Caching strategy** – The new `RecommendationCache` model stores
  precomputed recommendation lists keyed by user ID.  This demonstrates a
  thoughtful use of database tables to persist computed values and reduce
  recomputation.  An index on the cache’s `user_id` column accelerates lookup
  and retrieval of cached recommendations.

* **Security and configurability** – Refactoring the database configuration in
  `prs_project/settings.py` to read connection parameters from environment
  variables rather than hard‑coded strings shows attention to secure coding
  practices and deployment flexibility.  This change allows the same code base
  to connect to SQLite locally and to PostgreSQL or other databases in
  production without modification.

* **Documentation and defensive coding** – I added docstrings and help texts
  throughout the models to explain the purpose of the new fields and indices
  and to document valid ranges for rating values.  These improvements make the
  code more maintainable and reduce the chance of misuse.

### Course outcomes addressed

The enhancements support several CS 499 outcomes:

* **Outcome 3 – Design and evaluate computing solutions using algorithmic
  principles and data structures.**  By introducing a composite index and
  recommendation cache, I evaluated and implemented data‑structure
  optimizations that improve the performance of the recommendation algorithm.

* **Outcome 4 – Use innovative techniques and tools to implement computing
  solutions.**  Leveraging Django’s `Meta.indexes`, adding a caching table and
  reading configuration from environment variables demonstrate practical
  application of database best practices.

* **Outcome 5 – Develop a security mindset.**  Storing sensitive credentials
  outside of source control and validating rating values illustrate my
  awareness of potential vulnerabilities and mitigation strategies.

### Reflection on the enhancement process

Implementing the database enhancements deepened my understanding of how query
performance and data modelling choices affect application behaviour.  Defining
a composite index required reading Django’s documentation on custom indices and
testing the migration to ensure it created the expected database structure.
Designing the `RecommendationCache` model was an exercise in finding the right
data type (I chose `TextField` to store a JSON or comma‑delimited list of IDs)
and indexing for quick lookup.  Refactoring the database settings to use
environment variables involved considering defaults and documenting each
parameter so future maintainers can deploy the application securely.

One challenge was balancing backward compatibility with new features.  The
original code base uses SQLite for ease of setup, but real deployments may
require PostgreSQL or another DBMS.  Reading configuration from the
environment provided a non‑breaking way to support both scenarios.  Another
challenge was ensuring that the new cache table did not introduce stale
recommendations.  I addressed this by including a `created_at` timestamp to
support cache invalidation strategies, which could be implemented in the
future.

Overall, this milestone reinforced the importance of database design and
performance tuning in building responsive, scalable systems.  I learned how to
apply indexing, caching, and secure configuration techniques within Django to
improve both the efficiency and robustness of a real application.