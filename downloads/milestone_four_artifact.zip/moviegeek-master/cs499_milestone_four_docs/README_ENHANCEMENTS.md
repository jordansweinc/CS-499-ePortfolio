## Milestone Four Enhancements: Databases

This document summarizes the database‑related enhancements made to the **MovieGeek** project during
Milestone Four of the CS 499 capstone course.  These changes were designed to improve the
performance, flexibility, and security of the application’s data layer while also
demonstrating mastery of database design and tuning techniques.

### Composite index on ratings

The `Rating` model in `analytics/models.py` now defines a composite index on the
`user_id` and `movie_id` fields.  Prior to this enhancement, lookups for ratings by
user and movie required a full table scan, which did not scale for large datasets.
Defining a composite index via Django’s `Meta.indexes` speeds up these queries by
allowing the database to perform efficient key‐based lookups.  The `rating`
field now also includes validators to enforce a sensible range (0.0–5.0).

### Recommendation cache table

To reduce repeated computation of recommendations, a new model called
`RecommendationCache` was introduced in `recommender/models.py`.  This table
stores pre‑computed recommendation lists for each user, along with a creation
timestamp.  The cache can be populated by background jobs or on demand by the
recommendation engine.  An index on the `user_id` column was added to speed up
lookup of cached recommendations.

### Environment‑based database configuration

Previously, database connection parameters were hard‑coded in
`prs_project/settings.py`.  For Milestone Four these settings were refactored to
read values from environment variables (`DB_ENGINE`, `DB_NAME`, `DB_USER`,
`DB_PASSWORD`, `DB_HOST`, `DB_PORT`).  This change makes the application more
secure and portable, allowing a single code base to run against SQLite in
development and PostgreSQL or other databases in production.  If no environment
variables are set, the application falls back to a local SQLite database.

### Additional defensive coding and documentation

Throughout the models, docstrings and help texts were added to explain the
purpose of the new fields, indices and configuration settings.  This
documentation helps future developers understand why these changes were made
and how they impact performance and security.

### How to migrate

1.  Run Django migrations to create the new composite index and
    `recommendation_cache` table:

    ```bash
    python manage.py makemigrations
    python manage.py migrate
    ```

2.  Set appropriate environment variables in your deployment (optional):

    ```bash
    export DB_ENGINE=django.db.backends.postgresql
    export DB_NAME=moviegeek
    export DB_USER=your_username
    export DB_PASSWORD=your_password
    export DB_HOST=localhost
    export DB_PORT=5432
    ```

3.  Restart the Django application to pick up the new database configuration.

### Conclusion

These database enhancements demonstrate an ability to design and optimize data
models, implement caching strategies, and configure applications securely.
Together they reduce query times, support scalable recommendation caching, and
enable flexible deployment across environments.