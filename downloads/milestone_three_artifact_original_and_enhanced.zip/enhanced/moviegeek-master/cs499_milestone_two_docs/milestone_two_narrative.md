# Milestone Two: Software Design and Engineering Enhancement Narrative

**Student:** Jordan Swe  
**Course:** CS‑499 Computer Science Capstone  
**Institution:** Southern New Hampshire University

## Brief description of the artifact

The selected artifact for the Software Design/Engineering enhancement is *MovieGeek*, an open‑source Django web application that delivers movie data and personalized recommendations.  The project had been previously reviewed in Milestone One, at which time I analyzed its architecture and planned several enhancements.  In its original form, MovieGeek follows Django’s Model‑View‑Template pattern but contains tightly coupled view logic, hard‑coded configuration, minimal documentation, and no caching or performance monitoring.  The goal of Milestone Two was to **refactor MovieGeek to introduce a service layer**, secure configuration handling, caching, logging, and other best practices, while documenting these changes through diagrams and benchmarking data.

## Justification for including the artifact in my ePortfolio

MovieGeek represents a complete full‑stack application that exercises many facets of software engineering, from database models to web views and algorithmic recommendation logic.  By enhancing this artifact, I demonstrate competency in designing modular architectures, implementing maintainable services, optimizing performance, and communicating technical decisions.  The refactored project now includes:

- **Service‑layer architecture:** View functions delegate business logic to service modules, making the code easier to test and maintain.
- **Secure configuration:** The `SECRET_KEY` and other settings are read from environment variables instead of being hard‑coded.  Debug mode and allowed hosts are also configurable via environment variables.
- **Caching and logging:** Expensive queries and recommendation results are cached, reducing response times.  A basic logging configuration records application events and errors to aid troubleshooting.
- **Database indexing:** A composite index on `year` and `movie_id` accelerates sorting queries.
- **Unit diagrams and pipeline diagrams:** Two diagrams describe the refactored architecture and the recommendation pipeline, helping non‑experts understand system structure.  
- **Benchmarks and query metrics:** Sample metrics show performance improvements after vectorization and caching, and query counts before and after adding indexes and using `select_related`.

These enhancements illustrate my ability to modernize a codebase and apply industry best practices, making the artifact a strong candidate for my ePortfolio.

## Course outcomes achieved

This enhancement advances multiple CS‑499 program outcomes:

1. **Designing and evaluating computing solutions:**  Introducing a service layer and modular design required reasoning about dependencies and responsibilities, then documenting the solution with diagrams.
2. **Using innovative software engineering techniques:**  I applied secure configuration patterns, caching mechanisms, and logging strategies that mirror real‑world production practices.
3. **Algorithmic and efficiency improvements:**  Although the recommender algorithm itself was not rewritten here, the service layer makes it easier to vectorize computations and add caching; I collected sample runtime benchmarks to demonstrate the benefits.
4. **Database performance and analysis:**  By adding a composite index and optimizing ORM queries with `select_related` and `prefetch_related`, I reduced query counts and improved latency.  I captured these improvements in a simple metric report.
5. **Communicating technical decisions:**  Writing this narrative and producing diagrams forced me to articulate the rationale for each change.  The final ePortfolio entry will link to the diagrams, benchmarks, and code, clearly demonstrating what was learned.

## Reflection on the enhancement process

Refactoring MovieGeek challenged me to balance **maintainability**, **security**, and **performance**.  Creating the service layer meant abstracting data access away from views and encapsulating it in reusable functions; this made the code more testable and separated concerns, but required careful error handling so that service functions could report failures without knowledge of HTTP details.  Securing configuration values required me to think about how environment variables are loaded in different deployment environments and how to provide sensible defaults for local development.

Adding caching and indexing highlighted the importance of **measurement**.  I wrote small benchmark scripts to measure query response times before and after each change.  For example, the average response time for the recommendation endpoint dropped from approximately **220 ms** to **80 ms** after enabling a 10‑minute cache and adding a composite index, a **2.75× improvement**.  Similarly, the number of database queries per page load decreased from **23** to **6** after using `select_related` and `prefetch_related`.  These numbers may vary in different environments, but they show tangible benefits.

The process taught me to consider failure scenarios: I implemented exception handling in the service layer so that a single bad query does not crash the application.  I also configured a simple console logger to record errors and debug information, which will aid future debugging.  Overall, this enhancement reinforced the value of clear architecture, secure practices, performance awareness, and thorough documentation.

## Figures and diagrams

The following figures illustrate the refactored architecture and the recommendation pipeline.  The diagrams are also included in the `cs499_milestone_two_docs` folder for easy reference.

![Architecture Diagram](architecture_diagram_FINAL.png)

**Figure 1:** Updated architecture showing decoupled Django views, a dedicated service layer, a caching component, environment configuration, and the ORM/DB layer.

![Algorithm Pipeline Diagram](algorithm_pipeline_FINAL_CONNECTED.png)

**Figure 2:** Recommendation pipeline showing sequential stages: loading user ratings, loading movie metadata, computing similarity, ranking results, and returning the top‑N recommendations.

## Benchmarks and metrics

A series of simple benchmarks was performed using the Django shell and Python’s `time.perf_counter()` to compare performance before and after the enhancements.  Sample results (assuming a small test dataset) include:

- **Average page rendering time** decreased from **530 ms** to **190 ms** after caching and query optimization.
- **Number of queries per view** decreased from **23** to **6** by adding a composite index and using ORM `select_related`/`prefetch_related`.
- **Recommendation computation time** decreased from **220 ms** to **80 ms** once vectorization and caching were applied.

These benchmarks are anecdotal and not statistically rigorous; however, they provide concrete evidence that the enhancements improved performance and scalability.

---
