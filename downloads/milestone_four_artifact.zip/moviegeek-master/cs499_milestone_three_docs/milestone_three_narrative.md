# Milestone Three: Algorithms and Data Structures Enhancement Narrative

**Student:** Jordan Swe  
**Course:** CS‑499 Computer Science Capstone

## Artifact Description

This artifact is the recommendation engine of the MovieGeek web application.  The project originated as an open‑source demonstration of various recommendation algorithms, including item‑based nearest neighbour, matrix factorization, Bayesian Personalized Ranking, and popularity‑based strategies.  The algorithmic component enhanced for this milestone is the *item‑based neighbourhood recommender*, which was originally created in 2024 as part of the practical‑recommender‑systems project.  The recommender consumes user ratings and item similarity data to produce personalized recommendations.

## Justification for Inclusion

I selected this artifact because it showcases my ability to design and improve complex algorithms and to apply data structures effectively to deliver real value.  The enhancements include:

- **Caching prediction results.** The neighbourhood recommender now stores computed predictions in an in‑memory dictionary keyed by the target item and the user’s rating set.  This avoids recomputing the same prediction repeatedly during evaluation, reducing algorithmic complexity and improving runtime.  The cache key uses a sorted tuple of movie‑rating pairs to ensure uniqueness and hashability.  
- **Cold‑start fallback.** When a user has no ratings, the recommender delegates to the popularity‑based recommender instead of returning an empty list.  This improves the user experience by providing sensible suggestions even for new users.  
- **Input validation and defensive coding.** The revised implementation guards against empty similarity lists and zero similarity sums to avoid division by zero, returning a zero prediction when appropriate.  
- **Documentation.** I added docstrings and explanatory comments to clarify the purpose and behaviour of key functions and classes, making the algorithm easier to understand and maintain.

These changes required analyzing the original algorithm’s time complexity and memory usage, choosing appropriate data structures (dictionary and sorted tuples) for caching, and implementing a fallback algorithm for cold‑start scenarios.  They demonstrate algorithmic problem‑solving, data structure selection, and software craftsmanship.

## Outcome Coverage

These enhancements advance several CS‑499 outcomes:

- **Design and evaluate computing solutions** (Outcome 3): By introducing a caching mechanism and a cold‑start fallback, I improved the efficiency and robustness of the recommender.  The cache eliminates redundant computations and reduces the number of loop iterations, and the fallback ensures that a user always receives recommendations.
- **Innovative techniques, skills and tools** (Outcome 4): Implementing a custom cache using Python tuples and dictionaries demonstrates innovative use of data structures.  Integrating multiple recommender strategies (neighbourhood‑based and popularity‑based) required careful design to maintain clear separation of concerns.
- **Security mindset and defensive coding** (Outcome 5): The new implementation checks for zero denominators and handles empty inputs gracefully, reducing the risk of unhandled exceptions and potential vulnerabilities.

These enhancements meet the outcome‑coverage plan from Module One without changes.

## Reflection

Enhancing the recommendation algorithm taught me valuable lessons in balancing algorithmic complexity with maintainability.  Implementing caching required reasoning about hashable keys, memory trade‑offs, and ensuring safe concurrent access in a web context.  Adding a cold‑start fallback reminded me that algorithms must account for the full range of user behaviours; when there is no input data, a meaningful default is better than silence.  I also improved my familiarity with Django models and query optimization by limiting candidate item retrieval and integrating multiple recommendation strategies.  

The primary challenge was designing a cache key robust enough to handle different rating sets without collisions.  I solved this by converting the `movie_ids` dictionary into a sorted tuple of items (movie_id, rating), which is hashable and unique to the user’s current rating context.  Another challenge was finding a clean way to delegate to the popularity recommender without introducing circular imports; I resolved this by using relative imports within the package.  

With these changes, the recommender system is more efficient and adaptable, illustrating my competence in algorithms and data structures as well as my ability to document and communicate technical improvements effectively.

## Algorithm Pipeline Diagram

The following diagram illustrates the recommendation pipeline.  It applies equally to the original and improved implementation, but the caching layer now ensures that repeated calls to the `predict_score_by_ratings` function reuse stored results instead of recomputing them.

![Recommendation pipeline](algorithm_pipeline_FINAL_CONNECTED.png)