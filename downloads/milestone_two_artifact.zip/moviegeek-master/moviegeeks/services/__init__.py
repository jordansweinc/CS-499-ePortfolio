"""
Services package for moviegeeks.

This package contains reusable service-layer abstractions used by views.
Each service encapsulates a business concern and hides the underlying data
access implementation.  Service functions should avoid any direct references
to Django's HttpRequest or response objects.  They may raise exceptions to
signal failure, leaving the caller to catch and handle them.
"""

from .movie_service import list_movies, get_movie, list_genres

__all__ = ["list_movies", "get_movie", "list_genres"]